# Housing-price-prediction-using-Regularised-linear-regression
###### config
1. upload the ipynb file to Google colab

2. upload the csv file to Google colab 

3. run all cells





###### graph of error vs lambda in gradient descent
![g](https://raw.githubusercontent.com/SouravG/Housing-price-prediction-using-Regularised-linear-regression/master/download%20(1).png)


###### graph of error vs lambda in Normal equation
![g](https://raw.githubusercontent.com/SouravG/Housing-price-prediction-using-Regularised-linear-regression/master/download.png)
